"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mountAmgAuth = mountAmgAuth;
exports.identity = identity;
exports.requireRole = requireRole;
const identity_js_1 = require("./identity.js");
const login_js_1 = require("./login.js");
const page_js_1 = require("./page.js");
const ROLE_RANK = { member: 1, admin: 2, owner: 3 };
const PREFIX = '[amg]';
function matches(patterns, path) {
    return patterns.some((p) => (typeof p === 'string' ? path === p || path.startsWith(`${p}/`) : p.test(path)));
}
function readCookie(req, name) {
    const raw = req.cookies?.[name];
    if (typeof raw === 'string' && raw)
        return raw;
    // Respaldo para productos que no montan cookie-parser.
    const header = req.headers.cookie;
    if (!header)
        return undefined;
    for (const part of header.split(';')) {
        const [k, ...rest] = part.trim().split('=');
        if (k === name)
            return decodeURIComponent(rest.join('='));
    }
    return undefined;
}
function setSessionCookie(res, config, token) {
    res.cookie?.(config.sessionCookie, token, {
        httpOnly: true,
        sameSite: 'lax',
        secure: config.isProd,
        path: '/',
        maxAge: config.sessionDays * 24 * 60 * 60 * 1000,
    });
}
function clearSessionCookie(res, config) {
    res.clearCookie?.(config.sessionCookie, { path: '/' });
}
/**
 * Monta la identidad de AMG en un producto.
 *
 * Qué hace, en orden:
 *  1. `GET /auth/callback` canjea el código del Core y abre la sesión local.
 *  2. `GET /auth/logout` cierra la sesión local.
 *  3. En el resto de las rutas, valida la cookie contra el secreto del producto
 *     y pone `req.amg` con user_id / organization_id / role.
 *  4. Si no hay sesión válida, redirige al login del Core y vuelve con
 *     `?return_to=` a donde el usuario estaba.
 *
 * Lo que NO hace, a propósito: no hay `users` ni contraseñas en el producto.
 * `tenant_id` en las tablas del producto = `req.amg!.organizationId`.
 */
function mountAmgAuth(config, options = {}) {
    const publicPaths = options.publicPaths ?? ['/health', '/auth', '/webhooks', '/favicon.ico'];
    /**
     * ¿Va una respuesta JSON o una redirección?
     *
     * Una API responde 401 con el loginUrl en el cuerpo; una pagina navega al
     * login. Lo decide el `Accept` y, sobre todo, que el camino sea de API: un
     * fetch del navegador manda un Accept comodin, que `accepts('html')` lo daria
     * por HTML, y el fetch se comeria un 302 con la pagina de login del Core en
     * lugar de un 401. Por eso `/api/` siempre es JSON.
     */
    const wantsJson = (req) => !req.accepts('html') || req.path.startsWith('/api/');
    const renderError = options.renderError ??
        ((req, res, reason) => {
            const loginUrl = (0, login_js_1.buildLoginUrl)(config, req.originalUrl, req.originalUrl);
            if (wantsJson(req)) {
                res.status(401).json({ error: reason, message: (0, login_js_1.describeReason)(reason), loginUrl });
                return;
            }
            res
                .status(reason === 'sin-acceso' ? 403 : 401)
                .type('html')
                .send((0, page_js_1.errorPage)({
                title: reason === 'sin-acceso' ? 'Sin acceso' : 'Iniciá sesión',
                message: (0, login_js_1.describeReason)(reason),
                loginUrl,
                productName: options.productName,
            }));
        });
    const requireAuth = (req, res, next) => {
        if (matches(publicPaths, req.path))
            return next();
        if (req.amg)
            return next();
        const token = readCookie(req, config.sessionCookie);
        if (!token) {
            if (req.method === 'GET' && !wantsJson(req)) {
                return res.redirect(302, (0, login_js_1.buildLoginUrl)(config, req.originalUrl));
            }
            return res.status(401).json({
                error: 'sin-sesion',
                message: 'Tu sesión expiró o no existe. Iniciá sesión para continuar.',
                loginUrl: (0, login_js_1.buildLoginUrl)(config, req.originalUrl),
            });
        }
        const verified = (0, identity_js_1.verifyIdentity)(token, config);
        if (!verified.ok) {
            // Token viejo (emitido antes de un cambio de secreto), de otro producto o
            // manipulado: no es un error del usuario, así que limpiamos la cookie y
            // lo mandamos al login otra vez.
            clearSessionCookie(res, config);
            if (req.method === 'GET' && !wantsJson(req)) {
                return res.redirect(302, (0, login_js_1.buildLoginUrl)(config, req.originalUrl));
            }
            return res.status(401).json({
                error: verified.reason,
                message: (0, login_js_1.describeReason)(verified.reason),
                loginUrl: (0, login_js_1.buildLoginUrl)(config, req.originalUrl),
            });
        }
        req.amg = verified.identity;
        // Re-validación opcional contra el Core (ABMG_SSO_INTROSPECT=1): si el Core
        // dice que la sesión central o la suscripción ya no están, se corta acá.
        if (config.introspect) {
            (0, identity_js_1.introspect)(token, config)
                .then((result) => {
                if (result.ok && result.active)
                    return next();
                clearSessionCookie(res, config);
                renderError(req, res, result.ok ? 'sin-acceso' : 'core-caido');
            })
                .catch(() => next());
            return;
        }
        return next();
    };
    const callback = (req, res) => {
        void (async () => {
            const code = typeof req.query.code === 'string' ? req.query.code : undefined;
            const state = typeof req.query.state === 'string' ? req.query.state : undefined;
            if (!code)
                return res.status(400).send((0, page_js_1.errorPage)({ title: 'Falta el código', message: 'Volvé a iniciar sesión.', loginUrl: (0, login_js_1.buildLoginUrl)(config, '/'), productName: options.productName }));
            const exchanged = await (0, identity_js_1.exchangeCode)(code, config, (0, login_js_1.redirectUriFor)(config));
            if (!exchanged.ok) {
                // Un límite de solicitudes (429) o un Core momentáneamente caído no son un
                // callejón sin salida: el código ya se gastó, así que el reintento tiene que
                // volver a arrancar el authorize completo, no repetir este callback.
                const transitorio = exchanged.status === 429 || exchanged.status === 503;
                return res.status(exchanged.status ?? 400).send((0, page_js_1.errorPage)({
                    title: 'No pudimos iniciar sesión',
                    message: exchanged.reason,
                    retryUrl: transitorio ? (0, login_js_1.buildLoginUrl)(config, (0, login_js_1.isSafeReturnTo)(state) ? state : '/') : undefined,
                    retryAfterSeconds: exchanged.retryAfterSeconds,
                    productName: options.productName,
                }));
            }
            setSessionCookie(res, config, exchanged.accessToken);
            if (state && (0, login_js_1.isSafeReturnTo)(state))
                return res.redirect(302, state);
            res.redirect(302, '/');
        })();
    };
    const logout = (_req, res) => {
        clearSessionCookie(res, config);
        res.redirect(302, `${config.coreUrl}/api/logout?redirect=${encodeURIComponent(config.productUrl)}`);
    };
    // El callback y el logout se resuelven acá mismo, antes del guard: si no,
    // el guard los mandaría al login y nunca funcionarían.
    return (req, res, next) => {
        if (req.path === config.callbackPath)
            return callback(req, res, next);
        if (req.path === '/auth/logout')
            return logout(req, res, next);
        return requireAuth(req, res, next);
    };
}
/** Atajo para el patrón común: el producto pide la identidad y la usa. */
function identity(req) {
    if (!req.amg)
        throw new Error('identity() se llamó en una ruta sin mountAmgAuth()');
    return req.amg;
}
/** Para rutas que necesitan como mínimo un rol. */
function requireRole(minimum) {
    return (req, res, next) => {
        if (!req.amg) {
            return res.status(401).json({
                error: 'sin-sesion',
                message: 'Necesitás iniciar sesión para continuar.',
                loginUrl: undefined,
            });
        }
        if ((ROLE_RANK[req.amg.role] ?? 0) < ROLE_RANK[minimum]) {
            return res.status(403).json({ error: 'rol-insuficiente', necesario: minimum, actual: req.amg.role });
        }
        return next();
    };
}
//# sourceMappingURL=middleware.js.map