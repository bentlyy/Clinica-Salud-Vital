"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.encodeIdentityCookie = encodeIdentityCookie;
exports.decodeIdentityCookie = decodeIdentityCookie;
const node_crypto_1 = require("node:crypto");
/**
 * Versión "compacta" de la sesión, para productos que prefieran guardar un
 * valor chico en cookie en vez del access token entero.
 *
 * Va firmado con el mismo secreto de SSO del producto, así que es
 * verificable localmente sin llamar al Core. NO es un token de autorización:
 * para eso está `verifyIdentity` sobre el token del Core. Solo evita reescribir
 * los datos en cada request.
 */
function encodeIdentityCookie(identity, secret) {
    const payload = {
        userId: identity.userId,
        organizationId: identity.organizationId,
        role: identity.role,
        product: identity.product,
        sessionId: identity.sessionId,
        accessToken: '',
        expiresAt: identity.expiresAt ?? 0,
    };
    const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
    return `${body}.${sign(body, secret)}`;
}
function decodeIdentityCookie(value, secret, product) {
    const [body, mac] = value.split('.');
    if (!body || !mac)
        return null;
    const expected = sign(body, secret);
    if (!safeEqual(mac, expected))
        return null;
    try {
        const parsed = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
        if (parsed.product !== product)
            return null;
        if (typeof parsed.expiresAt === 'number' && parsed.expiresAt > 0 && parsed.expiresAt * 1000 < Date.now()) {
            return null;
        }
        return parsed;
    }
    catch {
        return null;
    }
}
function sign(body, secret) {
    return (0, node_crypto_1.createHmac)('sha256', secret).update(body).digest('base64url');
}
function safeEqual(a, b) {
    const ba = Buffer.from(a);
    const bb = Buffer.from(b);
    if (ba.length !== bb.length)
        return false;
    return (0, node_crypto_1.timingSafeEqual)(ba, bb);
}
//# sourceMappingURL=session.js.map