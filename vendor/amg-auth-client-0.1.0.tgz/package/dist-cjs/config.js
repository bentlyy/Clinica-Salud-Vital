"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadConfig = loadConfig;
const DEFAULTS = {
    callbackPath: '/auth/callback',
    sessionCookie: 'app_session',
    sessionDays: 30,
    introspect: false,
};
function bool(value, fallback) {
    if (value === undefined)
        return fallback;
    return value === '1' || value.toLowerCase() === 'true';
}
function loadConfig(env = process.env, productSlug) {
    const coreUrl = (env.CORE_URL ?? env.AMG_CORE_URL ?? 'http://localhost:3008').replace(/\/+$/, '');
    const clientId = env.AMG_SSO_CLIENT_ID ?? productSlug ?? '';
    const clientSecret = env.AMG_SSO_CLIENT_SECRET ?? '';
    const productUrl = (env.APP_URL ?? env.PUBLIC_URL ?? '').replace(/\/+$/, '');
    // Fail-fast: un producto sin secreto no puede validar a nadie, y es mejor que
    // no levante en lugar de levantar y dejar entrar a todo el mundo.
    if (!clientId) {
        throw new Error('Falta AMG_SSO_CLIENT_ID: identificá la aplicación (slug del producto)');
    }
    if (!clientSecret) {
        throw new Error(`Falta AMG_SSO_CLIENT_SECRET: pedilo con "npm run sso:secret -w @amg/platform -- ${clientId}" y ponelo en el .env de ${clientId}`);
    }
    if (!productUrl) {
        throw new Error(`Falta APP_URL: la URL pública de ${clientId} es la del subdominio que ya vive en el DNS (ej. https://inventario.amgdeveloper.cl para inventario, el mismo slug)`);
    }
    return {
        coreUrl,
        clientId,
        clientSecret,
        productUrl,
        isProd: env.NODE_ENV === 'production',
        callbackPath: env.AMG_CALLBACK_PATH ?? DEFAULTS.callbackPath,
        sessionCookie: env.AMG_SESSION_COOKIE ?? DEFAULTS.sessionCookie,
        sessionDays: Number(env.AMG_SESSION_DAYS ?? DEFAULTS.sessionDays),
        introspect: bool(env.AMG_SSO_INTROSPECT, DEFAULTS.introspect),
    };
}
//# sourceMappingURL=config.js.map