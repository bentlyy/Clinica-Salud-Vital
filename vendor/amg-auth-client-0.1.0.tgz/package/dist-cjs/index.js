"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.encodeIdentityCookie = exports.decodeIdentityCookie = exports.errorPage = exports.escapeHtml = exports.appendQuery = exports.describeReason = exports.isSafeReturnTo = exports.redirectUriFor = exports.buildLoginUrl = exports.requireRole = exports.identity = exports.mountAmgAuth = exports.exchangeCode = exports.introspect = exports.verifyIdentity = exports.loadConfig = void 0;
/**
 * @amg/auth-client — identidad de AMG para los subdominios.
 *
 * Un mini-SaaS NO tiene usuarios: no hay passwords, no hay tabla de cuentas,
 * no hay "¿te acordás de tu email?". La identidad vive en el Core y el
 * producto la recibe por SSO.
 *
 * Uso típico en el server de un producto:
 *
 *   import express from 'express';
 *   import cookieParser from 'cookie-parser';
 *   import { loadConfig, mountAmgAuth, identity } from '@amg/auth-client';
 *
 *   const app = express();
 *   const amg = loadConfig(process.env, 'inventario');
 *   app.use(cookieParser());
 *   app.use(mountAmgAuth(amg, { productName: 'Inventario' }));
 *
 *   app.get('/api/items', (req, res) => {
 *     const me = identity(req);
 *     // me.organizationId es el tenant_id de TODAS las filas de este producto
 *     res.json({ tenant: me.organizationId, user: me.userId, role: me.role });
 *   });
 */
var config_js_1 = require("./config.js");
Object.defineProperty(exports, "loadConfig", { enumerable: true, get: function () { return config_js_1.loadConfig; } });
var identity_js_1 = require("./identity.js");
Object.defineProperty(exports, "verifyIdentity", { enumerable: true, get: function () { return identity_js_1.verifyIdentity; } });
Object.defineProperty(exports, "introspect", { enumerable: true, get: function () { return identity_js_1.introspect; } });
Object.defineProperty(exports, "exchangeCode", { enumerable: true, get: function () { return identity_js_1.exchangeCode; } });
var middleware_js_1 = require("./middleware.js");
Object.defineProperty(exports, "mountAmgAuth", { enumerable: true, get: function () { return middleware_js_1.mountAmgAuth; } });
Object.defineProperty(exports, "identity", { enumerable: true, get: function () { return middleware_js_1.identity; } });
Object.defineProperty(exports, "requireRole", { enumerable: true, get: function () { return middleware_js_1.requireRole; } });
var login_js_1 = require("./login.js");
Object.defineProperty(exports, "buildLoginUrl", { enumerable: true, get: function () { return login_js_1.buildLoginUrl; } });
Object.defineProperty(exports, "redirectUriFor", { enumerable: true, get: function () { return login_js_1.redirectUriFor; } });
Object.defineProperty(exports, "isSafeReturnTo", { enumerable: true, get: function () { return login_js_1.isSafeReturnTo; } });
Object.defineProperty(exports, "describeReason", { enumerable: true, get: function () { return login_js_1.describeReason; } });
var page_js_1 = require("./page.js");
Object.defineProperty(exports, "appendQuery", { enumerable: true, get: function () { return page_js_1.appendQuery; } });
Object.defineProperty(exports, "escapeHtml", { enumerable: true, get: function () { return page_js_1.escapeHtml; } });
Object.defineProperty(exports, "errorPage", { enumerable: true, get: function () { return page_js_1.errorPage; } });
var session_js_1 = require("./session.js");
Object.defineProperty(exports, "decodeIdentityCookie", { enumerable: true, get: function () { return session_js_1.decodeIdentityCookie; } });
Object.defineProperty(exports, "encodeIdentityCookie", { enumerable: true, get: function () { return session_js_1.encodeIdentityCookie; } });
//# sourceMappingURL=index.js.map