"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorPage = void 0;
exports.redirectUriFor = redirectUriFor;
exports.buildLoginUrl = buildLoginUrl;
exports.isSafeReturnTo = isSafeReturnTo;
exports.describeReason = describeReason;
const page_js_1 = require("./page.js");
Object.defineProperty(exports, "errorPage", { enumerable: true, get: function () { return page_js_1.errorPage; } });
/**
 * La URL pública del producto, con la que el Core valida el redirect_uri.
 * Sin esto no hay forma de construir la callback correcta.
 */
function redirectUriFor(config) {
    return `${config.productUrl.replace(/\/+$/, '')}${config.callbackPath}`;
}
/**
 * A dónde mandamos al usuario que todavía no tiene sesión en el Core.
 *
 * El `return_to` se limita a rutas internas del PRODUCTO: si aceptáramos URLs
 * completas, un atacante podría usar nuestro login como redirector para
 * phishing. Solo se permiten rutas relativas que empiecen por "/" y no por
 * "//" (que el navegador leería como protocolo-relativo, o sea, otro sitio).
 */
function buildLoginUrl(config, returnTo, state) {
    const params = {
        client_id: config.clientId,
        redirect_uri: redirectUriFor(config),
        response_type: 'code',
    };
    if (returnTo && isSafeReturnTo(returnTo))
        params.return_to = returnTo;
    if (state)
        params.state = state;
    // OJO: la ruta es /api/sso/authorize (el router está montado en /api/sso).
    // Con `/sso/authorize` el Core responde 404 y el usuario queda trabado.
    return (0, page_js_1.appendQuery)(`${config.coreUrl}/api/sso/authorize`, params);
}
/** ¿Es seguro mandar al usuario a `returnTo`? */
function isSafeReturnTo(value) {
    if (typeof value !== 'string')
        return false;
    if (!value.startsWith('/'))
        return false;
    if (value.startsWith('//'))
        return false;
    if (value.includes('\\'))
        return false;
    return true;
}
const MESSAGES = {
    'sin-config': 'Este producto no está configurado para usar el inicio de sesión de AMG.',
    'sin-sesion': 'Tu sesión no está iniciada.',
    expirada: 'Tu sesión venció. Volvé a entrar para seguir.',
    audiencia: 'El inicio de sesión no corresponde a este producto.',
    invalido: 'No pudimos validar tu sesión. Volvé a entrar.',
    'sin-acceso': 'Tu organización no tiene acceso a este producto.',
    'core-caido': 'No pudimos contactar al servidor de acceso. Probá en unos segundos.',
    'otro-producto': 'Ese inicio de sesión es de otro producto.',
    'sin-rol': 'Tu rol no permite hacer esta acción.',
    'sin-organizacion': 'Tu sesión no tiene una organización asignada.',
};
function describeReason(reason) {
    return MESSAGES[reason] ?? MESSAGES.invalido;
}
//# sourceMappingURL=login.js.map